const bcrypt = require("bcryptjs")
const clientPromise = require("../../lib/mongodb")
const User = require("../../models/User")

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader("Access-Control-Allow-Credentials", true)
  res.setHeader("Access-Control-Allow-Origin", process.env.CORS_ORIGIN || "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT")
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version",
  )

  if (req.method === "OPTIONS") {
    res.status(200).end()
    return
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { name, email, password, phone, role } = req.body

    // Basic validation
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email, and password are required" })
    }

    if (password.length < 8) {
      return res.status(400).json({ error: "Password must be at least 8 characters long" })
    }

    // Connect to MongoDB
    const client = await clientPromise
    const db = client.db("medical_booking")
    const userModel = new User(db)

    // Check if user exists
    const existingUser = await userModel.findByEmail(email)
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const userData = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      phone: phone?.trim(),
      role: role || "patient",
    }

    const newUser = await userModel.create(userData)

    res.status(201).json({
      message: "User registered successfully",
      userId: newUser._id,
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({ error: "Registration failed" })
  }
}
