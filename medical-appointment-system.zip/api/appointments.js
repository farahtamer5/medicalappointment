const jwt = require("jsonwebtoken")
const clientPromise = require("../lib/mongodb")
const Appointment = require("../models/Appointment")

// Authentication helper
function authenticateToken(req) {
  const cookies = req.headers.cookie
  if (!cookies) return null

  const tokenCookie = cookies.split(";").find((c) => c.trim().startsWith("token="))
  if (!tokenCookie) return null

  const token = tokenCookie.split("=")[1]
  try {
    return jwt.verify(token, process.env.JWT_SECRET || "fallback-secret")
  } catch {
    return null
  }
}

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader("Access-Control-Allow-Credentials", true)
  res.setHeader("Access-Control-Allow-Origin", process.env.CORS_ORIGIN || "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT")
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version",
  )

  if (req.method === "OPTIONS") {
    res.status(200).end()
    return
  }

  // Authenticate user
  const user = authenticateToken(req)
  if (!user) {
    return res.status(401).json({ error: "Unauthorized" })
  }

  try {
    // Connect to MongoDB
    const client = await clientPromise
    const db = client.db("medical_booking")
    const appointmentModel = new Appointment(db)

    if (req.method === "GET") {
      // Get user appointments with doctor information
      const { status, limit = 50, offset = 0 } = req.query

      const appointments = await appointmentModel.getPatientAppointmentsWithDoctorInfo(user.userId, {
        status,
        limit,
        skip: Number.parseInt(offset),
      })

      // Format the response to match frontend expectations
      const formattedAppointments = appointments.map((apt) => ({
        id: apt._id,
        appointment_date: apt.appointmentDate,
        appointment_time: apt.appointmentTime,
        status: apt.status,
        symptoms: apt.symptoms,
        diagnosis: apt.diagnosis,
        prescription: apt.prescription,
        notes: apt.notes,
        created_at: apt.createdAt,
        doctor_name: apt.doctor.name,
        specialization: apt.doctor.specialization,
        consultation_fee: apt.doctor.consultationFee,
      }))

      res.status(200).json(formattedAppointments)
    } else if (req.method === "POST") {
      // Book new appointment
      const { doctor_id, appointment_date, appointment_time, symptoms } = req.body

      if (!doctor_id || !appointment_date || !appointment_time || !symptoms) {
        return res.status(400).json({ error: "All fields are required" })
      }

      // Validate appointment date
      const appointmentDate = new Date(appointment_date)
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      if (appointmentDate < today) {
        return res.status(400).json({ error: "Appointment date cannot be in the past" })
      }

      // Check if appointment slot is available
      const isAvailable = await appointmentModel.checkAvailability(doctor_id, appointment_date, appointment_time)

      if (!isAvailable) {
        return res.status(400).json({ error: "This time slot is already booked" })
      }

      // Book the appointment
      const appointmentData = {
        patientId: user.userId,
        doctorId: doctor_id,
        appointmentDate: appointment_date,
        appointmentTime: appointment_time,
        symptoms: symptoms.trim(),
      }

      const newAppointment = await appointmentModel.create(appointmentData)

      res.status(201).json({
        message: "Appointment booked successfully",
        appointmentId: newAppointment._id,
      })
    } else {
      res.status(405).json({ error: "Method not allowed" })
    }
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Database operation failed" })
  }
}
