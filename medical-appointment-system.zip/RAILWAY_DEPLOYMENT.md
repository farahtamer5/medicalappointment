# 🚂 Railway Deployment Guide - Medical Appointment Booking System

## Why Railway?

Railway is perfect for full-stack applications because:
- ✅ **Simple Deployment**: Git-based deployment
- ✅ **Built-in Database**: MongoDB hosting included
- ✅ **Environment Variables**: Easy configuration
- ✅ **Custom Domains**: Free HTTPS domains
- ✅ **Automatic Scaling**: Handles traffic spikes
- ✅ **Logs & Monitoring**: Built-in observability

## 🚀 Step-by-Step Deployment

### 1. Create Railway Account
1. Go to [railway.app](https://railway.app)
2. Sign up with GitHub (recommended)
3. Verify your account

### 2. Set Up Your Project

#### Option A: Deploy from GitHub (Recommended)
1. Push your code to GitHub repository
2. In Railway dashboard, click "New Project"
3. Select "Deploy from GitHub repo"
4. Choose your repository
5. Railway will automatically detect it's a Node.js app

#### Option B: Deploy with Railway CLI
\`\`\`bash
# Install Railway CLI
npm install -g @railway/cli

# Login to Railway
railway login

# Initialize project
railway init

# Deploy
railway up
\`\`\`

### 3. Add MongoDB Database

#### Option A: Railway MongoDB (Recommended)
1. In your Railway project dashboard
2. Click "New Service"
3. Select "Database" → "MongoDB"
4. Railway will provision a MongoDB instance
5. Copy the connection string from the Variables tab

#### Option B: MongoDB Atlas
1. Create MongoDB Atlas cluster (free tier)
2. Get connection string
3. Add as environment variable in Railway

### 4. Configure Environment Variables

In Railway dashboard → Your Project → Variables tab, add:

\`\`\`
NODE_ENV=production
MONGODB_URI=mongodb://mongo:password@mongodb.railway.internal:27017
JWT_SECRET=your-super-secret-jwt-key-minimum-32-characters
CORS_ORIGIN=https://your-app.up.railway.app
PORT=3000
\`\`\`

**Note**: Railway automatically provides the MONGODB_URI if you use Railway MongoDB.

### 5. Deploy and Test

1. Railway will automatically deploy when you push to GitHub
2. Check deployment logs in Railway dashboard
3. Visit your app URL (provided in Railway dashboard)
4. Test all functionality

## 🔧 Railway Configuration

### Automatic Deployment
Railway automatically deploys when you:
- Push to your main branch (GitHub)
- Use \`railway up\` command (CLI)

### Custom Domain (Optional)
1. Go to Settings → Domains
2. Add your custom domain
3. Configure DNS records as instructed
4. Update CORS_ORIGIN environment variable

### Environment Variables
Railway provides these automatically:
- \`PORT\` - Application port
- \`RAILWAY_ENVIRONMENT\` - Current environment
- \`MONGODB_URI\` - If using Railway MongoDB

## 📊 Database Setup

### Railway MongoDB
Railway automatically provides:
- MongoDB instance
- Connection string
- Automatic backups
- Monitoring

### Connection String Format
\`\`\`
mongodb://mongo:password@mongodb.railway.internal:27017
\`\`\`

### Database Initialization
Your app automatically:
- Creates collections and indexes
- Seeds sample doctors data
- Sets up proper database structure

## 🌐 Application URLs

After deployment, your app will be available at:
- **Main App**: \`https://your-app.up.railway.app\`
- **API Health**: \`https://your-app.up.railway.app/health\`
- **API Doctors**: \`https://your-app.up.railway.app/api/doctors\`

## 🧪 Testing Your Deployment

### 1. Health Check
\`\`\`bash
curl https://your-app.up.railway.app/health
\`\`\`

### 2. Test Registration
\`\`\`bash
curl -X POST https://your-app.up.railway.app/api/register \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "Test Patient",
    "email": "test@example.com",
    "password": "password123",
    "phone": "123-456-7890",
    "role": "patient"
  }'
\`\`\`

### 3. Test Frontend
1. Visit your Railway URL
2. Register a new account
3. Login and test all features
4. Book appointments
5. View appointment history

## 📈 Monitoring & Logs

### View Logs
1. Railway Dashboard → Your Project
2. Click on your service
3. Go to "Logs" tab
4. Real-time log streaming

### Metrics
Railway provides:
- CPU usage
- Memory usage
- Network traffic
- Response times

## 💰 Pricing

### Railway Pricing
- **Hobby Plan**: $5/month
  - 512MB RAM
  - 1GB disk
  - Custom domains
  - Unlimited projects

- **Pro Plan**: $20/month
  - 8GB RAM
  - 100GB disk
  - Priority support
  - Advanced metrics

### MongoDB Pricing
- **Railway MongoDB**: Included in plan
- **MongoDB Atlas**: Free tier available

## 🔒 Security Best Practices

### Environment Variables
- Never commit secrets to Git
- Use Railway's environment variables
- Rotate secrets regularly

### Database Security
- Railway MongoDB is private by default
- Use strong passwords
- Enable authentication

### Application Security
- HTTPS enabled by default
- CORS properly configured
- Input validation implemented

## 🚀 Scaling

### Automatic Scaling
Railway automatically scales based on:
- CPU usage
- Memory usage
- Request volume

### Manual Scaling
You can manually adjust:
- Memory allocation
- CPU allocation
- Replica count

## 🛠️ Troubleshooting

### Common Issues

1. **Build Failures**
   - Check package.json scripts
   - Verify Node.js version
   - Check build logs

2. **Database Connection Issues**
   - Verify MONGODB_URI
   - Check database service status
   - Review connection logs

3. **Environment Variables**
   - Ensure all required variables are set
   - Check variable names (case-sensitive)
   - Restart service after changes

### Debug Commands
\`\`\`bash
# View logs
railway logs

# Check variables
railway variables

# Connect to database
railway connect mongodb
\`\`\`

## 🔄 CI/CD Pipeline

Railway automatically:
1. **Detects Changes**: Monitors GitHub repository
2. **Builds Application**: Installs dependencies
3. **Runs Tests**: If test scripts are present
4. **Deploys**: Updates live application
5. **Health Checks**: Verifies deployment success

## 📱 Mobile Responsiveness

Your app is fully responsive and works on:
- ✅ Desktop browsers
- ✅ Tablets
- ✅ Mobile phones
- ✅ Progressive Web App (PWA) ready

## 🎯 Performance Optimization

Railway provides:
- **CDN**: Global content delivery
- **Compression**: Automatic gzip compression
- **Caching**: Static asset caching
- **HTTP/2**: Modern protocol support

---

## 🎉 Deployment Complete!

Your Medical Appointment Booking System is now live on Railway with:
- ✅ **Full-stack deployment**
- ✅ **MongoDB database**
- ✅ **Automatic scaling**
- ✅ **HTTPS security**
- ✅ **Custom domain support**
- ✅ **Real-time monitoring**

**Your app is ready for production use! 🚀**
\`\`\`

Finally, let's create a simple deployment script:
