"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Calendar, Clock, User, Heart, Plus, Activity } from "lucide-react"
import Navigation from "@/components/navigation"

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [appointments, setAppointments] = useState<any[]>([])
  const router = useRouter()

  useEffect(() => {
    const storedUser = localStorage.getItem("medibook_user")
    if (!storedUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(storedUser)
    setUser(userData)

    // Load sample appointments for demo
    const sampleAppointments = [
      {
        id: "1",
        doctorName: "Dr. Sarah Johnson",
        specialization: "Cardiology",
        date: "2024-12-30",
        time: "10:00 AM",
        status: "scheduled",
        symptoms: "Chest pain during exercise",
      },
      {
        id: "2",
        doctorName: "Dr. Michael Chen",
        specialization: "Dermatology",
        date: "2024-12-25",
        time: "2:00 PM",
        status: "completed",
        symptoms: "Skin rash on arms",
      },
    ]
    setAppointments(sampleAppointments)
  }, [router])

  if (!user) {
    return <div>Loading...</div>
  }

  const upcomingAppointments = appointments.filter((apt) => apt.status === "scheduled")
  const completedAppointments = appointments.filter((apt) => apt.status === "completed")

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {user.name}!</h1>
          <p className="text-gray-600">Here's an overview of your health appointments and activities.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="card">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Upcoming</p>
                <p className="text-2xl font-bold text-gray-900">{upcomingAppointments.length}</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-gray-900">{completedAppointments.length}</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center">
              <User className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Doctors</p>
                <p className="text-2xl font-bold text-gray-900">4</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-red-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Health Score</p>
                <p className="text-2xl font-bold text-gray-900">85%</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upcoming Appointments */}
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Upcoming Appointments</h2>
              <Link href="/book-appointment" className="btn btn-primary">
                <Plus className="h-4 w-4 mr-2" />
                Book New
              </Link>
            </div>

            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <div key={appointment.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{appointment.doctorName}</h3>
                        <p className="text-sm text-gray-600">{appointment.specialization}</p>
                        <div className="flex items-center mt-2 text-sm text-gray-500">
                          <Calendar className="h-4 w-4 mr-1" />
                          {appointment.date} at {appointment.time}
                        </div>
                      </div>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">Scheduled</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No upcoming appointments</p>
                <Link href="/book-appointment" className="btn btn-primary mt-4">
                  Book Your First Appointment
                </Link>
              </div>
            )}
          </div>

          {/* Recent Activity */}
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
              <Link href="/appointments" className="text-blue-600 hover:text-blue-700 text-sm">
                View All
              </Link>
            </div>

            <div className="space-y-4">
              {appointments.slice(0, 3).map((appointment) => (
                <div key={appointment.id} className="flex items-center space-x-3">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      appointment.status === "completed" ? "bg-green-500" : "bg-blue-500"
                    }`}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">Appointment with {appointment.doctorName}</p>
                    <p className="text-xs text-gray-500">
                      {appointment.date} - {appointment.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Link href="/book-appointment" className="card hover:shadow-lg transition-shadow">
              <div className="flex items-center">
                <Plus className="h-6 w-6 text-blue-600" />
                <span className="ml-3 font-medium">Book Appointment</span>
              </div>
            </Link>

            <Link href="/appointments" className="card hover:shadow-lg transition-shadow">
              <div className="flex items-center">
                <Calendar className="h-6 w-6 text-green-600" />
                <span className="ml-3 font-medium">View Appointments</span>
              </div>
            </Link>

            <Link href="/health-records" className="card hover:shadow-lg transition-shadow">
              <div className="flex items-center">
                <Activity className="h-6 w-6 text-purple-600" />
                <span className="ml-3 font-medium">Health Records</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
