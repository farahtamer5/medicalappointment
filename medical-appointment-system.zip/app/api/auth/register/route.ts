import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, phone } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Generate user ID
    const userId = `user-${Date.now()}`

    const response = NextResponse.json({
      success: true,
      user: {
        id: userId,
        name,
        email,
        role: "patient",
      },
    })

    response.cookies.set("auth-token", userId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 86400,
    })

    return response
  } catch (error) {
    return NextResponse.json({ error: "Registration failed" }, { status: 500 })
  }
}
