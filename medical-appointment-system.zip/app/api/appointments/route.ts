import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for demo (in production, use a database)
const appointments: any[] = [
  {
    id: "apt-1",
    patientId: "demo-patient-1",
    doctorId: "doc-1",
    appointment_date: "2024-12-30",
    appointment_time: "10:00 AM",
    status: "scheduled",
    symptoms: "Chest pain and shortness of breath during exercise",
    created_at: new Date().toISOString(),
  },
  {
    id: "apt-2",
    patientId: "demo-patient-1",
    doctorId: "doc-2",
    appointment_date: "2024-12-25",
    appointment_time: "2:00 PM",
    status: "completed",
    symptoms: "Skin rash on arms and legs",
    diagnosis: "Contact dermatitis",
    prescription: "Topical corticosteroid cream",
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  },
]

function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value
  if (!token) return null

  if (token === "demo-token") {
    return { id: "demo-patient-1" }
  }

  if (token.startsWith("user-")) {
    return { id: token }
  }

  return null
}

export async function GET(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userAppointments = appointments.filter((apt) => apt.patientId === user.id)

    // Add doctor information
    const doctors = [
      { id: "doc-1", name: "Sarah Johnson", specialization: "Cardiology", consultationFee: 150 },
      { id: "doc-2", name: "Michael Chen", specialization: "Dermatology", consultationFee: 120 },
      { id: "doc-3", name: "Emily Rodriguez", specialization: "Pediatrics", consultationFee: 100 },
      { id: "doc-4", name: "David Wilson", specialization: "Orthopedics", consultationFee: 180 },
    ]

    const enrichedAppointments = userAppointments.map((apt) => {
      const doctor = doctors.find((d) => d.id === apt.doctorId)
      return {
        ...apt,
        doctor_name: doctor?.name || "Unknown",
        specialization: doctor?.specialization || "General",
        consultation_fee: doctor?.consultationFee || 0,
      }
    })

    return NextResponse.json(enrichedAppointments)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { doctor_id, appointment_date, appointment_time, symptoms } = await request.json()

    if (!doctor_id || !appointment_date || !appointment_time || !symptoms) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const newAppointment = {
      id: `apt-${Date.now()}`,
      patientId: user.id,
      doctorId: doctor_id,
      appointment_date,
      appointment_time,
      status: "scheduled",
      symptoms,
      created_at: new Date().toISOString(),
    }

    appointments.push(newAppointment)

    return NextResponse.json({
      success: true,
      message: "Appointment booked successfully",
      appointmentId: newAppointment.id,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to book appointment" }, { status: 500 })
  }
}
