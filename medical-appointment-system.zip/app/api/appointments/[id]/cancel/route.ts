import { type NextRequest, NextResponse } from "next/server"

// This would connect to your database in production
const appointments: any[] = []

function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value
  if (!token) return null

  if (token === "demo-token") {
    return { id: "demo-patient-1" }
  }

  if (token.startsWith("user-")) {
    return { id: token }
  }

  return null
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const appointmentIndex = appointments.findIndex((apt) => apt.id === params.id && apt.patientId === user.id)

    if (appointmentIndex === -1) {
      return NextResponse.json({ error: "Appointment not found" }, { status: 404 })
    }

    appointments[appointmentIndex].status = "cancelled"

    return NextResponse.json({
      success: true,
      message: "Appointment cancelled successfully",
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to cancel appointment" }, { status: 500 })
  }
}
