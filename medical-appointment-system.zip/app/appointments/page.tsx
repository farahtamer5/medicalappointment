"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Calendar, Clock, User, CheckCircle, XCircle, AlertCircle } from "lucide-react"
import Navigation from "@/components/navigation"

export default function AppointmentsPage() {
  const [user, setUser] = useState<any>(null)
  const [appointments, setAppointments] = useState<any[]>([])
  const [filter, setFilter] = useState("all")
  const router = useRouter()

  useEffect(() => {
    const storedUser = localStorage.getItem("medibook_user")
    if (!storedUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(storedUser)
    setUser(userData)

    // Load sample appointments
    const sampleAppointments = [
      {
        id: "1",
        doctorName: "Dr. Sarah Johnson",
        specialization: "Cardiology",
        date: "2024-12-30",
        time: "10:00 AM",
        status: "scheduled",
        symptoms: "Chest pain during exercise",
        fee: 150,
        diagnosis: "",
        prescription: "",
      },
      {
        id: "2",
        doctorName: "Dr. Michael Chen",
        specialization: "Dermatology",
        date: "2024-12-25",
        time: "2:00 PM",
        status: "completed",
        symptoms: "Skin rash on arms and legs",
        fee: 120,
        diagnosis: "Contact dermatitis",
        prescription: "Topical corticosteroid cream, apply twice daily",
      },
      {
        id: "3",
        doctorName: "Dr. Emily Rodriguez",
        specialization: "Pediatrics",
        date: "2024-12-20",
        time: "11:00 AM",
        status: "cancelled",
        symptoms: "Fever and cough",
        fee: 100,
        diagnosis: "",
        prescription: "",
      },
      {
        id: "4",
        doctorName: "Dr. David Wilson",
        specialization: "Orthopedics",
        date: "2025-01-05",
        time: "9:00 AM",
        status: "scheduled",
        symptoms: "Knee pain after running",
        fee: 180,
        diagnosis: "",
        prescription: "",
      },
    ]
    setAppointments(sampleAppointments)
  }, [router])

  const handleCancelAppointment = (appointmentId: string) => {
    setAppointments((prev) => prev.map((apt) => (apt.id === appointmentId ? { ...apt, status: "cancelled" } : apt)))
  }

  if (!user) {
    return <div>Loading...</div>
  }

  const filteredAppointments = appointments.filter((apt) => {
    if (filter === "all") return true
    return apt.status === filter
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "scheduled":
        return <AlertCircle className="h-5 w-5 text-blue-600" />
      case "completed":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "cancelled":
        return <XCircle className="h-5 w-5 text-red-600" />
      default:
        return <Clock className="h-5 w-5 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Appointments</h1>
          <p className="text-gray-600">Manage and view your medical appointments</p>
        </div>

        {/* Filter Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {[
                { key: "all", label: "All Appointments" },
                { key: "scheduled", label: "Upcoming" },
                { key: "completed", label: "Completed" },
                { key: "cancelled", label: "Cancelled" },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setFilter(tab.key)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    filter === tab.key
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Appointments List */}
        {filteredAppointments.length > 0 ? (
          <div className="space-y-4">
            {filteredAppointments.map((appointment) => (
              <div key={appointment.id} className="card">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                      <User className="h-6 w-6 text-gray-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{appointment.doctorName}</h3>
                      <p className="text-gray-600">{appointment.specialization}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="h-4 w-4 mr-1" />
                          {appointment.date}
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="h-4 w-4 mr-1" />
                          {appointment.time}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center space-x-2 mb-2">
                      {getStatusIcon(appointment.status)}
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}
                      >
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">Fee: ${appointment.fee}</p>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-gray-900 mb-1">Symptoms</h4>
                      <p className="text-sm text-gray-600">{appointment.symptoms}</p>
                    </div>

                    {appointment.diagnosis && (
                      <div>
                        <h4 className="font-medium text-gray-900 mb-1">Diagnosis</h4>
                        <p className="text-sm text-gray-600">{appointment.diagnosis}</p>
                      </div>
                    )}
                  </div>

                  {appointment.prescription && (
                    <div className="mt-3">
                      <h4 className="font-medium text-gray-900 mb-1">Prescription</h4>
                      <p className="text-sm text-gray-600">{appointment.prescription}</p>
                    </div>
                  )}

                  {appointment.status === "scheduled" && (
                    <div className="mt-4 flex space-x-3">
                      <button
                        onClick={() => handleCancelAppointment(appointment.id)}
                        className="btn bg-red-600 text-white hover:bg-red-700"
                      >
                        Cancel Appointment
                      </button>
                      <button className="btn btn-secondary">Reschedule</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No appointments found</h3>
            <p className="text-gray-600 mb-6">
              {filter === "all" ? "You haven't booked any appointments yet." : `No ${filter} appointments found.`}
            </p>
            <button onClick={() => router.push("/book-appointment")} className="btn btn-primary">
              Book Your First Appointment
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
