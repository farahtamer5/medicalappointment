"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Calendar, User, Star, DollarSign } from "lucide-react"
import Navigation from "@/components/navigation"

const doctors = [
  {
    id: "doc-1",
    name: "Dr. Sarah Johnson",
    specialization: "Cardiology",
    experience: 15,
    fee: 150,
    rating: 4.9,
    availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    timeSlots: ["9:00 AM", "10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM", "4:00 PM"],
  },
  {
    id: "doc-2",
    name: "Dr. Michael Chen",
    specialization: "Dermatology",
    experience: 12,
    fee: 120,
    rating: 4.8,
    availableDays: ["Monday", "Wednesday", "Friday"],
    timeSlots: ["10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM", "4:00 PM"],
  },
  {
    id: "doc-3",
    name: "Dr. Emily Rodriguez",
    specialization: "Pediatrics",
    experience: 8,
    fee: 100,
    rating: 4.7,
    availableDays: ["Tuesday", "Thursday", "Saturday"],
    timeSlots: ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM"],
  },
  {
    id: "doc-4",
    name: "Dr. David Wilson",
    specialization: "Orthopedics",
    experience: 20,
    fee: 180,
    rating: 4.9,
    availableDays: ["Monday", "Tuesday", "Thursday", "Friday"],
    timeSlots: ["9:00 AM", "10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM"],
  },
]

export default function BookAppointmentPage() {
  const [user, setUser] = useState<any>(null)
  const [selectedDoctor, setSelectedDoctor] = useState<any>(null)
  const [selectedDate, setSelectedDate] = useState("")
  const [selectedTime, setSelectedTime] = useState("")
  const [symptoms, setSymptoms] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const storedUser = localStorage.getItem("medibook_user")
    if (!storedUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(storedUser))
  }, [router])

  const handleBookAppointment = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate booking process
    setTimeout(() => {
      setSuccess(true)
      setIsLoading(false)

      // Reset form after 3 seconds and redirect
      setTimeout(() => {
        router.push("/appointments")
      }, 3000)
    }, 1500)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="flex items-center justify-center py-20">
          <div className="card max-w-md text-center">
            <div className="text-green-600 mb-4">
              <Calendar className="h-16 w-16 mx-auto" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Appointment Booked Successfully!</h2>
            <p className="text-gray-600 mb-4">
              Your appointment with {selectedDoctor?.name} has been confirmed for {selectedDate} at {selectedTime}.
            </p>
            <p className="text-sm text-gray-500">Redirecting to your appointments...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Book an Appointment</h1>
          <p className="text-gray-600">Choose a doctor and schedule your appointment</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Doctor Selection */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Select a Doctor</h2>
            <div className="grid gap-4">
              {doctors.map((doctor) => (
                <div
                  key={doctor.id}
                  className={`card cursor-pointer transition-all ${
                    selectedDoctor?.id === doctor.id ? "ring-2 ring-blue-500 bg-blue-50" : "hover:shadow-lg"
                  }`}
                  onClick={() => setSelectedDoctor(doctor)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                        <User className="h-8 w-8 text-gray-500" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
                        <p className="text-gray-600">{doctor.specialization}</p>
                        <div className="flex items-center space-x-4 mt-1">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 fill-current" />
                            <span className="text-sm text-gray-600 ml-1">{doctor.rating}</span>
                          </div>
                          <span className="text-sm text-gray-600">{doctor.experience} years exp.</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center text-gray-600">
                        <DollarSign className="h-4 w-4" />
                        <span className="font-semibold">{doctor.fee}</span>
                      </div>
                      <p className="text-sm text-gray-500">Consultation</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Appointment Form */}
          <div className="card">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Appointment Details</h2>

            {selectedDoctor ? (
              <form onSubmit={handleBookAppointment} className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-medium text-blue-900">{selectedDoctor.name}</h3>
                  <p className="text-blue-700">{selectedDoctor.specialization}</p>
                  <p className="text-sm text-blue-600">Fee: ${selectedDoctor.fee}</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
                  <input
                    type="date"
                    required
                    className="input"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Select Time</label>
                  <select
                    required
                    className="input"
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                  >
                    <option value="">Choose a time slot</option>
                    {selectedDoctor.timeSlots.map((time: string) => (
                      <option key={time} value={time}>
                        {time}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Symptoms / Reason for Visit</label>
                  <textarea
                    required
                    rows={4}
                    className="input"
                    placeholder="Describe your symptoms or reason for the appointment..."
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                  />
                </div>

                <button type="submit" disabled={isLoading} className="w-full btn btn-primary py-3 disabled:opacity-50">
                  {isLoading ? "Booking..." : "Book Appointment"}
                </button>
              </form>
            ) : (
              <div className="text-center py-8">
                <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Please select a doctor to continue</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
