# 🚀 Deployment Guide - Medical Appointment Booking System

## Vercel Deployment

### Prerequisites
1. **Vercel Account**: Sign up at [vercel.com](https://vercel.com)
2. **Cloud Database**: Set up a MySQL database (recommended providers below)
3. **Git Repository**: Push your code to GitHub, GitLab, or Bitbucket

### Recommended Database Providers

#### Option 1: PlanetScale (Recommended)
- Free tier available
- MySQL-compatible
- Serverless scaling
- Setup: [planetscale.com](https://planetscale.com)

#### Option 2: Railway
- Simple setup
- MySQL support
- Free tier available
- Setup: [railway.app](https://railway.app)

#### Option 3: Supabase
- PostgreSQL (requires minor code changes)
- Free tier available
- Setup: [supabase.com](https://supabase.com)

### Step-by-Step Deployment

#### 1. Prepare Your Database

**For PlanetScale:**
\`\`\`bash
# Install PlanetScale CLI
npm install -g @planetscale/cli

# Login and create database
pscale auth login
pscale database create medical-booking
pscale branch create medical-booking main

# Get connection string
pscale connect medical-booking main --port 3309
\`\`\`

**For Railway:**
\`\`\`bash
# Install Railway CLI
npm install -g @railway/cli

# Login and create project
railway login
railway new
railway add mysql

# Get connection details from Railway dashboard
\`\`\`

#### 2. Set Up Database Schema

Connect to your database and run:
\`\`\`sql
-- Copy the contents from database/backup.sql
-- Or use the initialization script
\`\`\`

#### 3. Deploy to Vercel

**Option A: Using Vercel CLI**
\`\`\`bash
# Install Vercel CLI
npm install -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Set environment variables
vercel env add DB_HOST
vercel env add DB_USER
vercel env add DB_PASSWORD
vercel env add DB_NAME
vercel env add JWT_SECRET
vercel env add CORS_ORIGIN

# Deploy to production
vercel --prod
\`\`\`

**Option B: Using Vercel Dashboard**
1. Go to [vercel.com/dashboard](https://vercel.com/dashboard)
2. Click "New Project"
3. Import your Git repository
4. Configure environment variables:
   - `DB_HOST`: Your database host
   - `DB_USER`: Database username
   - `DB_PASSWORD`: Database password
   - `DB_NAME`: Database name (medical_booking)
   - `JWT_SECRET`: Random secure string
   - `CORS_ORIGIN`: Your domain (e.g., https://your-app.vercel.app)
5. Click "Deploy"

#### 4. Environment Variables Setup

In Vercel Dashboard → Project → Settings → Environment Variables:

\`\`\`
DB_HOST=your-database-host
DB_USER=your-database-user
DB_PASSWORD=your-database-password
DB_NAME=medical_booking
JWT_SECRET=your-super-secret-jwt-key-min-32-chars
CORS_ORIGIN=https://your-app.vercel.app
NODE_ENV=production
\`\`\`

#### 5. Custom Domain (Optional)

1. Go to Project Settings → Domains
2. Add your custom domain
3. Configure DNS records as instructed
4. Update CORS_ORIGIN environment variable

### Database Connection Strings

**PlanetScale Format:**
\`\`\`
mysql://username:password@host:port/database?ssl={"rejectUnauthorized":true}
\`\`\`

**Railway Format:**
\`\`\`
mysql://root:password@containers-us-west-xxx.railway.app:port/railway
\`\`\`

**Standard MySQL Format:**
\`\`\`
mysql://user:password@host:port/database
\`\`\`

### Troubleshooting

#### Common Issues:

1. **Database Connection Failed**
   - Verify environment variables
   - Check database is running
   - Ensure SSL settings are correct

2. **CORS Errors**
   - Set CORS_ORIGIN to your Vercel domain
   - Include https:// in the URL

3. **Function Timeout**
   - Database queries taking too long
   - Check database performance
   - Optimize queries

4. **Authentication Issues**
   - Verify JWT_SECRET is set
   - Check cookie settings
   - Ensure HTTPS in production

#### Debug Commands:
\`\`\`bash
# Check deployment logs
vercel logs

# Test API endpoints
curl https://your-app.vercel.app/api/health

# Check environment variables
vercel env ls
\`\`\`

### Performance Optimization

1. **Database Indexing**: Ensure proper indexes on frequently queried columns
2. **Connection Pooling**: Use connection pooling for better performance
3. **Caching**: Implement caching for static data like doctors list
4. **CDN**: Vercel automatically provides CDN for static assets

### Security Checklist

- ✅ Environment variables are set securely
- ✅ Database uses SSL connections
- ✅ JWT secret is strong and unique
- ✅ CORS is configured properly
- ✅ Input validation is implemented
- ✅ Rate limiting is in place

### Monitoring

1. **Vercel Analytics**: Enable in project settings
2. **Error Tracking**: Monitor function logs
3. **Database Monitoring**: Use your database provider's monitoring tools
4. **Uptime Monitoring**: Set up external monitoring

### Backup Strategy

1. **Database Backups**: Configure automatic backups with your provider
2. **Code Backups**: Ensure code is in version control
3. **Environment Variables**: Keep secure backup of environment variables

### Cost Optimization

1. **Vercel**: Free tier includes 100GB bandwidth
2. **Database**: Use free tiers for development/testing
3. **Monitoring**: Set up billing alerts

### Support

- **Vercel Support**: [vercel.com/support](https://vercel.com/support)
- **Database Provider Support**: Check your provider's documentation
- **Community**: Stack Overflow, Discord communities

---

**Your Medical Appointment Booking System is now ready for production! 🎉**
\`\`\`

Let's create a simple database initialization script for cloud databases:
