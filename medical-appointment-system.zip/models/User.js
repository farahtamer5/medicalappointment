const { ObjectId } = require("mongodb")

class User {
  constructor(db) {
    this.collection = db.collection("users")
    this.createIndexes()
  }

  async createIndexes() {
    try {
      await this.collection.createIndex({ email: 1 }, { unique: true })
      await this.collection.createIndex({ role: 1 })
      await this.collection.createIndex({ createdAt: 1 })
    } catch (error) {
      console.log("Indexes might already exist:", error.message)
    }
  }

  async create(userData) {
    const user = {
      ...userData,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    const result = await this.collection.insertOne(user)
    return { ...user, _id: result.insertedId }
  }

  async findByEmail(email) {
    return await this.collection.findOne({ email })
  }

  async findById(id) {
    return await this.collection.findOne({ _id: new ObjectId(id) })
  }

  async updateById(id, updateData) {
    const result = await this.collection.updateOne(
      { _id: new ObjectId(id) },
      { $set: { ...updateData, updatedAt: new Date() } },
    )
    return result
  }

  async deleteById(id) {
    return await this.collection.deleteOne({ _id: new ObjectId(id) })
  }

  async findByRole(role) {
    return await this.collection.find({ role }).toArray()
  }
}

module.exports = User
