const { ObjectId } = require("mongodb")

class Appointment {
  constructor(db) {
    this.collection = db.collection("appointments")
    this.createIndexes()
  }

  async createIndexes() {
    try {
      await this.collection.createIndex({ patientId: 1 })
      await this.collection.createIndex({ doctorId: 1 })
      await this.collection.createIndex({ appointmentDate: 1 })
      await this.collection.createIndex({ status: 1 })
      await this.collection.createIndex({ createdAt: 1 })
      // Compound index for checking availability
      await this.collection.createIndex(
        { doctorId: 1, appointmentDate: 1, appointmentTime: 1 },
        { unique: true, partialFilterExpression: { status: { $ne: "cancelled" } } },
      )
    } catch (error) {
      console.log("Indexes might already exist:", error.message)
    }
  }

  async create(appointmentData) {
    const appointment = {
      ...appointmentData,
      patientId: new ObjectId(appointmentData.patientId),
      doctorId: new ObjectId(appointmentData.doctorId),
      status: "scheduled",
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    const result = await this.collection.insertOne(appointment)
    return { ...appointment, _id: result.insertedId }
  }

  async findByPatientId(patientId, options = {}) {
    const { status, limit = 50, skip = 0 } = options
    const query = { patientId: new ObjectId(patientId) }

    if (status && status !== "all") {
      query.status = status
    }

    return await this.collection
      .find(query)
      .sort({ appointmentDate: -1, appointmentTime: -1 })
      .limit(Number.parseInt(limit))
      .skip(Number.parseInt(skip))
      .toArray()
  }

  async findByDoctorId(doctorId, options = {}) {
    const { status, limit = 50, skip = 0 } = options
    const query = { doctorId: new ObjectId(doctorId) }

    if (status && status !== "all") {
      query.status = status
    }

    return await this.collection
      .find(query)
      .sort({ appointmentDate: 1, appointmentTime: 1 })
      .limit(Number.parseInt(limit))
      .skip(Number.parseInt(skip))
      .toArray()
  }

  async findById(id) {
    return await this.collection.findOne({ _id: new ObjectId(id) })
  }

  async checkAvailability(doctorId, appointmentDate, appointmentTime) {
    const existing = await this.collection.findOne({
      doctorId: new ObjectId(doctorId),
      appointmentDate,
      appointmentTime,
      status: { $ne: "cancelled" },
    })
    return !existing
  }

  async updateById(id, updateData) {
    return await this.collection.updateOne(
      { _id: new ObjectId(id) },
      { $set: { ...updateData, updatedAt: new Date() } },
    )
  }

  async cancelById(id, userId) {
    return await this.collection.updateOne(
      { _id: new ObjectId(id), patientId: new ObjectId(userId) },
      { $set: { status: "cancelled", updatedAt: new Date() } },
    )
  }

  async getPatientAppointmentsWithDoctorInfo(patientId, options = {}) {
    const { status, limit = 50, skip = 0 } = options
    const matchStage = { patientId: new ObjectId(patientId) }

    if (status && status !== "all") {
      matchStage.status = status
    }

    return await this.collection
      .aggregate([
        { $match: matchStage },
        {
          $lookup: {
            from: "doctors",
            localField: "doctorId",
            foreignField: "_id",
            as: "doctor",
          },
        },
        { $unwind: "$doctor" },
        {
          $project: {
            appointmentDate: 1,
            appointmentTime: 1,
            status: 1,
            symptoms: 1,
            diagnosis: 1,
            prescription: 1,
            notes: 1,
            createdAt: 1,
            "doctor.name": 1,
            "doctor.specialization": 1,
            "doctor.consultationFee": 1,
          },
        },
        { $sort: { appointmentDate: -1, appointmentTime: -1 } },
        { $skip: Number.parseInt(skip) },
        { $limit: Number.parseInt(limit) },
      ])
      .toArray()
  }
}

module.exports = Appointment
