const { ObjectId } = require("mongodb")

class Doctor {
  constructor(db) {
    this.collection = db.collection("doctors")
    this.createIndexes()
  }

  async createIndexes() {
    try {
      await this.collection.createIndex({ email: 1 }, { unique: true })
      await this.collection.createIndex({ specialization: 1 })
      await this.collection.createIndex({ name: 1 })
      await this.collection.createIndex({ availableDays: 1 })
    } catch (error) {
      console.log("Indexes might already exist:", error.message)
    }
  }

  async create(doctorData) {
    const doctor = {
      ...doctorData,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    const result = await this.collection.insertOne(doctor)
    return { ...doctor, _id: result.insertedId }
  }

  async findAll() {
    return await this.collection
      .find({})
      .sort({ name: 1 })
      .project({
        name: 1,
        specialization: 1,
        availableDays: 1,
        availableHours: 1,
        consultationFee: 1,
        experienceYears: 1,
        qualification: 1,
      })
      .toArray()
  }

  async findById(id) {
    return await this.collection.findOne({ _id: new ObjectId(id) })
  }

  async findBySpecialization(specialization) {
    return await this.collection.find({ specialization }).toArray()
  }

  async updateById(id, updateData) {
    return await this.collection.updateOne(
      { _id: new ObjectId(id) },
      { $set: { ...updateData, updatedAt: new Date() } },
    )
  }

  async deleteById(id) {
    return await this.collection.deleteOne({ _id: new ObjectId(id) })
  }
}

module.exports = Doctor
