#!/bin/bash

echo "🚂 Medical Appointment Booking System - Railway Deployment"
echo "=========================================================="

# Check if Railway CLI is installed
if ! command -v railway &> /dev/null; then
    echo "📦 Installing Railway CLI..."
    npm install -g @railway/cli
fi

# Check if logged in to Railway
if ! railway whoami &> /dev/null; then
    echo "🔐 Please login to Railway..."
    railway login
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if this is a new project
if [ ! -f "railway.toml" ]; then
    echo "🆕 Initializing new Railway project..."
    railway init
fi

# Set environment variables
echo "🔧 Setting up environment variables..."
echo "Please set the following environment variables in Railway dashboard:"
echo "  - JWT_SECRET (generate a strong secret)"
echo "  - CORS_ORIGIN (your Railway app URL)"
echo "  - NODE_ENV=production"
echo ""
echo "If using Railway MongoDB, MONGODB_URI will be set automatically."
echo "If using external MongoDB, set MONGODB_URI manually."

# Deploy to Railway
echo "🚀 Deploying to Railway..."
railway up

echo "✅ Deployment initiated!"
echo "🌐 Check your Railway dashboard for the app URL"
echo "📋 Don't forget to:"
echo "   1. Set environment variables in Railway dashboard"
echo "   2. Add MongoDB service if not already added"
echo "   3. Test your application endpoints"
echo "   4. Configure custom domain if needed"
